
import java.util.regex.Pattern;


public class Additional_Modules implements Runnable {
    String Thread_Name;
    private Thread t;
    private String Hash_output;
    private String Num_Gen_output;
    private static String hash;
    Additional_Modules(){
        
    }
    
    private void hashcode_Code(){
        String output="#";
        int t=0;
        char test;
        for(int i=0;i<hash.length();i++){
            if(hash.charAt(i)>='A'&&hash.charAt(i)<='N'){
                t=hash.charAt(i)+10;
                output=output+t;
            }
            else if(hash.charAt(i)>'N'&&hash.charAt(i)<='Z'){
                t=hash.charAt(i)-6;
                test=(char)t;
                output=output+test;
            }
            else if(hash.charAt(i)>='0'&&hash.charAt(i)<='9'){
                 if(hash.charAt(i)>='0'&&hash.charAt(i)<='3'){
                    output=output+hash.charAt(i)+"S";
                }
                else if(hash.charAt(i)>='4'&&hash.charAt(i)<='6'){
                    output=output+hash.charAt(i)+"H";
                }
                if(hash.charAt(i)>='7'&&hash.charAt(i)<='9'){
                    output=output+hash.charAt(i)+"M";
                }
            }
            else if(hash.charAt(i)>='a'&&hash.charAt(i)<='b'){
                t=hash.charAt(i)+6;
                output=output+t;
            }
            else if(hash.charAt(i)>'n'&&hash.charAt(i)<='z'){
                t=hash.charAt(i)-10;
                test=(char)t;
                output=output+test;
            }
            else{
                 output=output+hash.charAt(i);
            }     
    }
         Hash_output=output;
    }
    
     private void NumGen_Code(){
           double b;
        int a,count=0;
        char k;
        String output="",l;
            while(count<3){
            b=Math.random();
            b=b*100;
            a=(int)b;
            if(a>=65&&a<=90){
             count=count+1;
            k=(char)a;
            l=Character.toString(k);
            output=output.concat(l);
              }
            }
            count =0;
            while(count<5)
            {
            b=Math.random();
            b=b*10;
            a=(int)b;
            if(a<10){
                l=String.valueOf(a);
              output=output.concat(l);
              count=count+1;
            }
            }
    Num_Gen_output=output;
    }

    @Override
    public void run() {
       if(Thread_Name=="hashcode"){
           hashcode_Code();
       }
       else if(Thread_Name=="NumGen"){
           NumGen_Code();
       }
       else{
           System.out.println("Invalide function calling");
       }
    }
    
    public void hashcode (String name,String hash) {
        Thread_Name="hashcode";
        this.hash=hash;
   if (t == null) {
   t = new Thread (this, Thread_Name);
   t.start ();
}
}
       public void NumGen (String name) {
        Thread_Name="NumGen";
   if (t == null) {
   t = new Thread (this, Thread_Name);
   t.start ();
}
}
    public boolean Email_validator(String Email){
    String EmailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    Pattern p= Pattern.compile(EmailRegex);
    if(p.matcher(Email).matches())
        return true;
     else
        return false;
}
public boolean CNIC_validator(String Email){
    String CNICRegex = "^[0-9]{13}$";
    Pattern p= Pattern.compile(CNICRegex);
    if(p.matcher(Email).matches())
        return true;
     else
        return false;
}
public boolean Name_validator(String Email){
  String nameRegex = "^[a-zA-Z\\s]+$";
    Pattern p= Pattern.compile(nameRegex);
    if(p.matcher(Email).matches())
        return true;
     else
        return false;
}
public boolean Password_validator(String Email){
   String passwordRegex = "^(?=.*[A-Za-z]{6,})(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?])(?=.*[0-9].*[0-9]).*$";
    Pattern p= Pattern.compile(passwordRegex);
    if(p.matcher(Email).matches())
        return true;
     else
        return false;
}
public boolean Phone_Number_validator(String Email){
 String phoneNumberRegex = "^\\d{11}$";
 Pattern p= Pattern.compile(phoneNumberRegex);
    if(p.matcher(Email).matches())
        return true;
     else
        return false;
}
}
