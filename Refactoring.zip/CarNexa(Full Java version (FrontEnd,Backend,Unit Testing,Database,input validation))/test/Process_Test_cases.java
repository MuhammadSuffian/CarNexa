/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author stu
 */
public class Process_Test_cases {
    
    public Process_Test_cases() {
    }
   @Test
   public void Password_Hasing_Test(){
          Additional_Modules obj=new Additional_Modules();
        String restult=obj.hashcode("Qwerty12345");
        assertEquals("#Kmehjo1S2S3S4H5H",restult);
    }
   
   
   public void Token_ID_Generator_Test(){
          Additional_Modules obj=new Additional_Modules();
        String restult=obj.numGen();
        if(restult!=obj.numGen()){
          assertEquals(restult,restult);  
        }
        else{
            assertEquals("Hello",restult);  
        }
    }
}
