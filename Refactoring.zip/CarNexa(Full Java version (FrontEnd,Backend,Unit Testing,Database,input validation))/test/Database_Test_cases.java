/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author stu
 */
public class Database_Test_cases {
    
    public Database_Test_cases() {
    }
   @Test
   public void Login_Test(){
          Singelton_Pattern obj=new Singelton_Pattern();
        boolean restult=obj.login("Farzam@gmail.com","Faz");
        assertEquals(false,restult);
    }
   
   public void Signup_Test(){
        Singelton_Pattern obj=new Singelton_Pattern();
        boolean restult=obj.Sigup("Suffian","mspakistan59@gmail.com",387576379,"Qwerty12345");
        assertEquals(false,restult);
    }
   
   public void Account_delete_Test(){
        Singelton_Pattern obj=new Singelton_Pattern();
        boolean restult=obj.delete("mspakistan59@gmail.com");
        assertEquals(false,restult);
    }
   
   public void booking_Test(){
        Singelton_Pattern obj=new Singelton_Pattern();
        boolean restult=obj.booking("mspakistan59@gmail.com","BIKE", "RIQ-380",2016, "General Checkup","GSH58332");
        assertEquals(false,restult);
    }
   
   
 
    
}
