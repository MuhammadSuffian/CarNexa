
import java.io.*;  
import java.net.ServerSocket;  
import java.net.Socket;  
  
public class Server_Socket { 
    
    public static String FAQ(String msg){
        String a="";
        if(msg.trim().equals("1")){
            a="1:Go To inital Screen\n2:Go to Create New Account\n3:Fill in required Fields with relenevent data\n4:Click Sign Up";
        }
        else if(msg.trim().equals("2")){
               a="1:Go To inital Screen\n2:Fill in required Fields with relenevent data\n3:Click Login Button";
        }
        else if(msg.trim().equals("3")){
               a="1:Go To inital Screen\n2:Fill in required Fields with relenevent data\n3:Click Login Button\n4:A new appointement form will be opened\n5:Fill in required Fields with relenevent data\n6:Click appointements Button";
        }
        else if(msg.trim().equals("4")){
             a="Tokken ID is a unique ID assignemend to every appointement and used to manage appointements";
        }
        else{
            a="Invalid input please contact ADMIN";
        }
        return a;
    }
  
  public static void main(String[] args) throws IOException {   
      Socket socket ;  
      
      InputStreamReader inputStreamReader ;  
      OutputStreamWriter outputStreamWriter ;  
      BufferedReader bufferedReader ;  
      BufferedWriter bufferedWriter ;  
      ServerSocket serversocket ;  
  
      serversocket = new ServerSocket(5089);  
  
      while (true) {  
          try {  
         
              socket = serversocket.accept();  
      
              inputStreamReader = new InputStreamReader(socket.getInputStream());  
              outputStreamWriter = new OutputStreamWriter(socket.getOutputStream());  
                    bufferedReader = new BufferedReader(inputStreamReader);  
              bufferedWriter = new BufferedWriter(outputStreamWriter);  

              while (true){  
                  String msgFromClient = bufferedReader.readLine(); 
                  String  response="";
                  response=FAQ(msgFromClient);
                  System.out.println("Client: " + msgFromClient);   
                  bufferedWriter.write(response+"\nBYE"); 
                  bufferedWriter.newLine();  
                  bufferedWriter.flush(); 

                  if (msgFromClient.equalsIgnoreCase("BYE"))  
                  break;  
              }  
              socket.close();  
              inputStreamReader.close();  
              outputStreamWriter.close();  
              bufferedReader.close();  
              bufferedWriter.close();  

          } catch (IOException e) {  
              e.printStackTrace();  
          }  
        }  
    }  
}
