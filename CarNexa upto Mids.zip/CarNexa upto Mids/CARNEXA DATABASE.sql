-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2023 at 05:09 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carnexa`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `Gmail` varchar(254) DEFAULT NULL,
  `Car_Category` varchar(20) DEFAULT NULL,
  `Registeration_Number` varchar(20) DEFAULT NULL,
  `Model_Year` int(4) DEFAULT NULL,
  `Appointement` varchar(20) DEFAULT NULL,
  `Appointement_ID` varchar(9) NOT NULL,
  `Status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`Gmail`, `Car_Category`, `Registeration_Number`, `Model_Year`, `Appointement`, `Appointement_ID`, `Status`) VALUES
('mspakistan59@gmail.com', 'BIKE', 'RIQ-380', 2016, 'General Checkup', 'GSH58332', 0),
('waqas@gmail.com', 'SUV/MPV/PICKUP', 'RIQ-1', 2023, 'General Checkup', 'HFD30229', 0),
('shaheen@gmail.com', 'SEDAN/SPORTS SEDAN ', 'RIQ-105', 2023, 'General Checkup', 'IAO70327', 0),
('waqas@gmail.com', 'BIKE', 'RIQ-380', 2016, 'Face-up-lift', 'JSI48251', 0),
('far@gmail.com', 'BIKE', 'RIQ-380', 2016, 'General Checkup', 'MYY80549', 0),
('mspakistan59@gmail.com', 'HATCH/HOT HATCH', 'RIQ-69', 1969, 'Suspension issue', 'OPZ67495', 0),
('waqas@gmail.com', 'SEDAN/SPORTS SEDAN ', 'RIQ-1999', 1999, 'Suspension issue', 'TNV87043', 0),
('mspakistan59@gmail.com', 'SUV/MPV/PICKUP', 'RIJ-117', 2021, 'Enigine issue', 'ZHZ07892', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Name` varchar(32) NOT NULL,
  `Gmail` varchar(254) NOT NULL,
  `Cnic` int(13) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Name`, `Gmail`, `Cnic`, `Password`) VALUES
('Farzam', 'far@gmail.com', 87654, '#f103h'),
('Muhammad Farzam Baig', 'Farzambaig2016@gmail.com', 3740587, '#1S2S3S4H5H6H'),
('Suffian', 'mspakistan59@gmail.com', 12345567, '#87103lik5H9M5H9M'),
('Shaheen', 'shaheen@gmail.com', 9876543, '#1S2S3S4H5H'),
('WaqasChaudary ', 'waqas@gmail.com', 0, '#Q103g103i1S2S3S');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `CID` int(10) NOT NULL,
  `NAME` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`CID`, `NAME`) VALUES
(136, 'M Farzam baig'),
(138, 'M.Suffian Tafoor');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`Appointement_ID`),
  ADD KEY `Gmail` (`Gmail`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Gmail`),
  ADD UNIQUE KEY `Cnic` (`Cnic`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`CID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`Gmail`) REFERENCES `customer` (`Gmail`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
