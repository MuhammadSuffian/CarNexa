

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import javax.swing.JOptionPane;
 
public class Singelton_Pattern {

    public void print(){
         try (
         Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/carnexa","root","")){  
           Statement   stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select * from customer");
        while(rs.next()){
            System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"   "+rs.getString(4));
        }
    }
catch(Exception e){ 
    System.out.println(e);
} 
    }
    
     public boolean Sigup(String Name,String Gamil,double CNIC,String password){
         try (
         Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/carnexa","root","")){  
         Statement stmt=con.createStatement();
         String sql = "INSERT INTO `customer` (`Name`, `Gmail`,`Cnic`,`Password`,`Status`) VALUES ('"+Name+"' , '"+Gamil+"' , '"+CNIC+"' , '"+password +"' , '0"+"')";
         int rowsAffected = stmt.executeUpdate(sql);
         return true;
    }
catch(Exception e){ 
    System.out.println(e);
    return false;
} 
    }
     
     public boolean login(String Gmail,String password){
         try (
         Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/carnexa","root","")){  
         Statement stmt=con.createStatement();
         ResultSet rs = stmt.executeQuery("SELECT * FROM `customer` WHERE Gmail='" + Gmail + "' AND Password='" + password + "'");
         while(rs.next()){
          System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"   "+rs.getString(4));
         if(rs.getString(2).equals(Gmail)&&rs.getString(4).equals(password)){
             return true;
         }
          }
         return false;
    }
catch(Exception e){ 
    return false;
} 
    }
     
     
      public boolean delete(String gmail){
         try (
         Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/carnexa","root","")){  
           Statement   stmt=con.createStatement();
           String sql = "DELETE FROM `customer` WHERE `gmail` = '"+gmail+"'";
           int rowsAffected = stmt.executeUpdate(sql);
           return true;
    }
catch(Exception e){ 
    System.out.println(e);
    return false;
} 
    }
      
      
      public boolean booking(String Gmail,String Car_Category,String Registeration_Number,int Model_Year,String Appointement,String Appointement_ID){
         try (
         Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/carnexa","root","")){  
         Statement stmt=con.createStatement();
         String sql = "INSERT INTO `bookings` (`Gmail`, `Car_Category`,`Registeration_Number`,`Model_Year`,`Appointement`,`Appointement_ID`) VALUES ('"+Gmail+"' , '"+Car_Category+"' , '"+Registeration_Number+"' , '"+Model_Year +"' , '"+Appointement+"' , '"+Appointement_ID+"')";
         int rowsAffected = stmt.executeUpdate(sql);
         return true;
    }
catch(Exception e){ 
    System.out.println(e);
    return false;
} 
    }
    
}
